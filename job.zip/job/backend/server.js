import app from "./app.js";
import cloudinary from "cloudinary";

cloudinary.v2.config({
  cloud_name: "dc22i4iqc",
  api_key: "193138418828264",
  api_secret: "ZMObTlOdszaYhz-sYciZjAD63f0",
});

const PORT = 8000;

app.listen(PORT, () => {
  console.log(`Server running at port ${PORT}`);
});
